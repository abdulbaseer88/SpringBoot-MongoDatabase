package in.nareshit.raghu;

import lombok.Data;

@Data
public class Course {
	
	private Integer cid;
	private  String cname;
	private Double cfee;
	
}