package in.nareshit.raghu;

import java.util.List;

import lombok.Data;

@Data
public class Student {

	private Integer sid;
	private String sname;
	private List<Course> courses;

}