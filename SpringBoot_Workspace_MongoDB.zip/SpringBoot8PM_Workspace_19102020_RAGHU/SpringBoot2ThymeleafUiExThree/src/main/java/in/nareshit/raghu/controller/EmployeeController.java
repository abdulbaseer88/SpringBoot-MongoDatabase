package in.nareshit.raghu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.nareshit.raghu.model.Employee;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	@GetMapping("/register")
	public String showRegister(Model model) {
		Employee e = new Employee();
		/*
		e.setEmpId(new Random().nextInt(1000));
		e.setProject("P1");
		e.setSlots(Arrays.asList("A","B"));
		*/
		model.addAttribute("employee", e);
		return "EmployeeRegister";
	}
	@PostMapping("/save")
	public String showData(
			@ModelAttribute Employee employee,
			Model model)
	{
		model.addAttribute("eob", employee);
		return "EmployeeView";
	}
}
