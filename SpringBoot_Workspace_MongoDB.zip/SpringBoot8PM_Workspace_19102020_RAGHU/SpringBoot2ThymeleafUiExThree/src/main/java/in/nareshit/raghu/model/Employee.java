package in.nareshit.raghu.model;

import java.util.List;

import lombok.Data;

@Data
public class Employee {

	private Integer empId;
	private String empName;
	private String gender;
	private Double empSal;
	private String project;
	private List<String> slots;
	private String address;
}
