package in.nareshit.raghu.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import in.nareshit.raghu.model.Book;

public interface BookRepository extends MongoRepository<Book, Integer> {

	//---custom query methods---------
	
	//SQL: SELECT * FROM BOOK WHERE ID=?
	@Query("{id : ?0 }")
	Optional<Book> getBookById(Integer id);
	
	@Query("{ pages :  { $lt: ?0 } }") // where pages<?
	//@Query("{ pages :  { $gte: ?0 } }") // where pages>=?
	//@Query("{ pages : ?0 }") // where pages=?
	List<Book> getBooksByPages(Integer pages);
	
	
	// where author = ?
	@Query("{ author : ?0 }")
	List<Book> getBooksByAuthor(String author);
	
	// where author = ? and btype =? 
	@Query("{ author : ?0 , btype: ?1}")
	List<Book> getBooksByAuthorAndType(String author,String btype);
	
	
	// where author = ? or btype =? 
	//@Query("{$and : [{ author : ?0 } , { btype: ?1}]}")
	@Query("{$or : [{ author : ?0 } , { btype: ?1}]}")
	List<Book> getBooksByAuthorOrType(String author,String btype);
	
	
	//SQL: select count(*) from book where author=?
	@Query(value = "{ author : ?0}", count = true)
	Integer getBooksCountByAuthor(String author);
	
	//Sorting
	@Query(value = "{ author : ?0}", sort ="{ bname:1 }") //ASC
	//@Query(value = "{ author : ?0}", sort ="{ bname:-1 }") //DESC
	List<Book> getBooksByAuthorortByBname(String author);
	
	
	//=========================================================
	@Query(
			value="{ btype : ?0 }",    // where condition
			fields = "{ id : 0 ,  bname : 1, author : 1  }"    //select clause
			)
	List<Book> getBookNameAndAuthorByType(String btype);
	
	//SQL : select count(*) from book where author=? > 0  
	@Query(value = "{ author : ?0}", exists = true)
	Boolean isBookExistByAuthor(String author);
	
	
	// where author = ?
	@Query("{ author : { $regex : ?0 } }")
	List<Book> getBooksByAuthorRegEx(String author);
	
	
	
}
