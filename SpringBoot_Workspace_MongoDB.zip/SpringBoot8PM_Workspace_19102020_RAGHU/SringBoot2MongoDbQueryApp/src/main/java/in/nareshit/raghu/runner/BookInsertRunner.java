package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import in.nareshit.raghu.model.Book;
import in.nareshit.raghu.repo.BookRepository;

//@Component
public class BookInsertRunner implements CommandLineRunner {
	@Autowired
	private BookRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.deleteAll();
		
		repo.save(new Book(100, "Core Java", 200, "SAM", "BASICS"));
		repo.save(new Book(101, "Adv Java",  300, "SAM", "WEB"));
		repo.save(new Book(102, "SPRING",    480, "SYED", "WEB"));
		repo.save(new Book(103, "ANGULAR",   260, "SYED", "UI"));
		repo.save(new Book(104, "HTML CSS",  100, "RAM", "UI"));
		repo.save(new Book(105, "C++",       180, "SAM", "BASICS"));
		repo.save(new Book(106, "C",         100, "RAM", "BASICS"));
		repo.save(new Book(107, "SPRING BOOT",850, "RAM", "WEB"));
		repo.save(new Book(108, "JQuery",    120, "SYED", "UI"));
		repo.save(new Book(109, "DP",        280, "SAM", "BASICS"));
		
		System.out.println("___DONE___");
	}

}
