package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.repo.BookRepository;

@Component
public class TestQueryRunner implements CommandLineRunner {
	@Autowired
	private BookRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		/*
		Optional<Book> opt =  repo.getBookById(100);
		if(opt.isPresent()) System.out.println(opt.get());
		else System.out.println("DATA NOT FOUND");
		*/
		
		//repo.getBooksByAuthor("SAM").forEach(System.out::println);
		//repo.getBooksByPages(400).forEach(System.out::println);
		//repo.getBooksByAuthorAndType("SAM","BASICS").forEach(System.out::println);
		//repo.getBooksByAuthorOrType("SAM","BASICS").forEach(System.out::println);
		
		//Integer count = repo.getBooksCountByAuthor("SAM");	System.out.println(count);
		
		//repo.getBooksByAuthorortByBname("SAM").forEach(System.out::println);
		
		//repo.getBookNameAndAuthorByType("BASICS").forEach(System.out::println);
		
		//boolean exist = repo.isBookExistByAuthor("SAM");
		//System.out.println(exist);
		
		//starts with S => ^S (In SQL : S%)
		//repo.getBooksByAuthorRegEx("^S").forEach(System.out::println);
		
		// ends with AM => AM$ ( In SQL : %AM)
		//repo.getBooksByAuthorRegEx("AM$").forEach(System.out::println);
		
		// contains A => ^A% (or A) [in SQL : %A%]
		repo.getBooksByAuthorRegEx("Y").forEach(System.out::println);
		//repo.getBooksByAuthorRegEx("^Y$").forEach(System.out::println);
		
	}

}
