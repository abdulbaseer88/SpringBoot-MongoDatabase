package in.nareshit.raghu.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Spring 4.0 -> @Controller + @ResponseBody
@RequestMapping("/student")
public class StudentRestController {

	@GetMapping("/show")
	public ResponseEntity<String> showMsg() {
		String body = "WELCOME TO FIRST APP!";
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<String> response = new ResponseEntity<String>(body, status);
		return response;
	}
}
