package in.nareshit.raghu.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import in.nareshit.raghu.model.Product;

public interface ProductRepositry extends MongoRepository<Product, String> {

	
}
