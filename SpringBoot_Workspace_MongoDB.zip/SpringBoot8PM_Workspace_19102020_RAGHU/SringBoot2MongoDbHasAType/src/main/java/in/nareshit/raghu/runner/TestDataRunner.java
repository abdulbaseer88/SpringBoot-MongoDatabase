package in.nareshit.raghu.runner;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Info;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.model.Vendor;
import in.nareshit.raghu.repo.ProductRepositry;

@Component
public class TestDataRunner implements CommandLineRunner {
	@Autowired
	private ProductRepositry repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.deleteAll();
		
		Product pob = new Product("A001", 101, "PEN", 50.0,
				List.of(
						new Vendor(100, "VA"),
						new Vendor(101, "VB"),
						new Vendor(102, "VC")
						),
				Map.of(
						"I1", new Info(55,"OK"),
						"I2", new Info(56,"ACTIVE"),
						"I3", new Info(57,"DONE")
						)
				);
		
		repo.save(pob);
		
		System.out.println("___DONE__");
	}
}
