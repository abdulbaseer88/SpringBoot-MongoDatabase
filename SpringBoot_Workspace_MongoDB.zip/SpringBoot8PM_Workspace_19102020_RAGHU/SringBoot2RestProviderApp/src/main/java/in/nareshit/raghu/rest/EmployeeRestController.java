package in.nareshit.raghu.rest;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Employee;

@RestController
@RequestMapping("/emp")
public class EmployeeRestController {

	private Logger log = LoggerFactory.getLogger(EmployeeRestController.class);

	@PutMapping("/modify/{id}")
	public ResponseEntity<String> updateEmployee(
			@PathVariable Integer id,
			@RequestBody Employee employee
			) 
	{
		log.info("FROM REST CONTROLLER-PUT METHOD ....");
		employee.setId(id);
		return ResponseEntity.ok(employee.toString());
	}
	
	
	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeEmployee(
			@PathVariable Integer id) 
	{
		log.info("FROM REST CONTROLLER-DELETE METHOD ....");
		return ResponseEntity.ok("Employee removed with id "+id);
	}
	

	@GetMapping("/find/{id}")
	public ResponseEntity<Employee> getOneEmployee(@PathVariable Integer id)
	{
		return ResponseEntity.ok(new Employee(id, "TEST", 555.0));
	}

	@GetMapping("/all")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		return ResponseEntity.ok(Arrays.asList(
				new Employee(10, "T1", 555.0),
				new Employee(11, "T2", 585.0),
				new Employee(12, "T3", 550.0)
				)
				);
	}


	@GetMapping("/msg/{id}/{code}")
	public ResponseEntity<String> showMsg(
			@PathVariable Integer id,
			@PathVariable String code
			) 
	{
		log.info("FROM REST CONTROLLER-GET");
		return new ResponseEntity<String>("Hello:"+id+","+code,HttpStatus.OK);
	}

	@PostMapping("/save")
	public ResponseEntity<String> saveEmp(
			@RequestBody Employee employee) {
		log.info("FROM REST CONTROLLER-POST");
		return new ResponseEntity<String>(
				employee.toString(),HttpStatus.OK);
	}



}
