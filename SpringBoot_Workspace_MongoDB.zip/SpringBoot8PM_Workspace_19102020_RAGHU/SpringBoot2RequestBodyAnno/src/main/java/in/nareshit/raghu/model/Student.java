package in.nareshit.raghu.model;

import java.util.Map;

import lombok.Data;

@Data
public class Student {

	private Integer id;
	private String name;
	private Double fee;
	
	//private List<String> courses;
	//private Set<String> courses;
	private String[] courses;
	
	private Map<String,String> result; 
	//private Properties result;
	
	private Address addr;
}
