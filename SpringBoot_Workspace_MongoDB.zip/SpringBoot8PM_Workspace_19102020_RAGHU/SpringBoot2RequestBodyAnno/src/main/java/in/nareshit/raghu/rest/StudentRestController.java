package in.nareshit.raghu.rest;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Student;

@RestController
public class StudentRestController {

	@PostMapping("/create")
	public String readData(
			@RequestBody Student student) 
	{
		return student.toString();
	}
}
