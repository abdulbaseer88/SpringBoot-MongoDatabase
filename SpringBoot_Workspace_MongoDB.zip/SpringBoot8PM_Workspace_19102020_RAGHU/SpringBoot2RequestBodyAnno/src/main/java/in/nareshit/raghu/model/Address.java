package in.nareshit.raghu.model;

import lombok.Data;

@Data
public class Address {

	private String hno;
	private String loc;
}
