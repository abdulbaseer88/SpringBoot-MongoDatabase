package in.nareshit.raghu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Contract;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.model.Vendor;

@RestController
public class ProductRestController {

	//1.  Primitive(String)
	@GetMapping("/a")
	public String showA() {
		return "Hello Text Data!";
	}
	
	//2. Class/Object
	@GetMapping("/b")
	public Product showB() {
		return new Product(10,"PEN",500.0);
	}
	
	
	//3. List/Set Type
	@GetMapping("/c")
	public List<Product> showC() {
		return List.of(
				new Product(101,"A",400.0),
				new Product(102,"B",500.0),
				new Product(103,"C",600.0)
				);
	}
	
	//4. Map/Properties Type
	@GetMapping("/d")
	public Map<String,String> showD() {
		return Map.of(
					"P1","ABC",
					"P2","NIT",
					"P3","MNO"
				);
	}
	
	@GetMapping("/d2")
	public Map<String,Product> showD2() {
		return Map.of(
					"P1",new Product(101,"A",400.0),
					"P2",new Product(102,"B",500.0),
					"P3",new Product(103,"C",600.0)
				);
	}
	
	//5. HAS-A Type
	@GetMapping("/e")
	public Vendor showE() {
		return new Vendor(
				"AA-NIT", 
				"HYD", 
				new Contract(550, "HTC-EM", 50000.0)
				);
	}
	
	//6. Using Any Type + ResponseEntity
	// TODO 
	
	
}
