package in.nareshit.raghu.runner;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Employee;

@Component
public class TestMongoOperations implements CommandLineRunner {
	@Autowired
	private MongoTemplate mt;
	
	@Override
	public void run(String... args) throws Exception {
		
		mt.dropCollection("employee");
		
		//save(object,collectioName)
		mt.save(new Employee("A001", 101, "A", 3.3,"DEV"));
		mt.save(new Employee("A002", 102, "B", 4.3,"QA"));
		mt.save(new Employee("A003", 103, "C", 5.3,"DEV"));
		mt.save(new Employee("A004", 104, "D", 5.3,"QA"));
		mt.save(new Employee("A005", 105, "E", 5.3,"DEV"));

		//Query query = new Query();
		//query.addCriteria(Criteria.where("empId").is(101));
		
		mt.remove(Employee.class).all();
		
		//mt.findAndRemove(query, Employee.class);
		
		/*
		Query query = new Query();
		//Like: select * from employee where dept=DEV
		//query.addCriteria(Criteria.where("dept").is("DEV"));

		//Like: select * from employee where empId=101
		query.addCriteria(Criteria.where("empId").is(101));
		
		// update empsal=600
		Update update = new Update();
		update.set("empSal", 600.0);
		update.set("empName", "A NEW");
		
		mt.findAndModify(query, update, Employee.class);
		*/
		
		/*
		//List<Employee>  list =  mt.findAll(Employee.class,"emp");
		List<Employee>  list =  mt.findAll(Employee.class);
		list.forEach(System.out::println);
		
		System.out.println("____________________");
		//Employee emp = mt.findById("A001", Employee.class);
		Employee emp = mt.findById("A009", Employee.class);
		System.out.println(emp);
		*/
		
		System.out.println("__DONE__");
		
	}

}
