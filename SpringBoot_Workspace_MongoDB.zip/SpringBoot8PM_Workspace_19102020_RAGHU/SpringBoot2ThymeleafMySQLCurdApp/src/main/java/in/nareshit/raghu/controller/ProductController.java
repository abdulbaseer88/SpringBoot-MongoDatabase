package in.nareshit.raghu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.service.IProductService;

@Controller
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private IProductService service;

	//1. show Register page
	@GetMapping("/register")
	public String showReg(Model model) 
	{
		//Form Backing Object
		model.addAttribute("product", new Product());
		return "ProductAdd";
	}
	
	//2. Read Form data and save in db
	@PostMapping("/save")
	public String save(
			@ModelAttribute Product product, 
			Model model)
	{
		Integer id  = service.saveProduct(product);
		model.addAttribute("message", "Product '"+id+"' Saved");
		// clear form data
		model.addAttribute("product", new Product());
		return "ProductAdd";
	}
	
	//3. Read data from DB and show at UI
	@GetMapping("/all")
	public String showAll(Model model) {
		List<Product> list = service.getAllProducts();
		model.addAttribute("list", list);
		return "ProductAll";
	}
	
	//4. delete row based on ID
	@GetMapping("/delete")
	public String delete(
			@RequestParam Integer id,
			Model model) 
	{
		service.deleteProduct(id);
		model.addAttribute("list", service.getAllProducts());
		model.addAttribute("message", "Product '"+id+"' Deleted");
		return "ProductAll";
	}
	
	//5. show edit page with data
	@GetMapping("/edit")
	public String showEdit(
			@RequestParam Integer id,
			Model model) 
	{
		// send object data to form data
		model.addAttribute("product",service.getOneProduct(id));
		return "ProductEdit";
	}
	
	
	//6. perform update operation
	@PostMapping("/update")
	public String update(
			@ModelAttribute Product product,
			Model model) 
	{
		service.updateProduct(product);
		model.addAttribute("list", service.getAllProducts());
		model.addAttribute("message", "Product '"+product.getId()+"' Updated");
		return "ProductAll";
	}
	
}
