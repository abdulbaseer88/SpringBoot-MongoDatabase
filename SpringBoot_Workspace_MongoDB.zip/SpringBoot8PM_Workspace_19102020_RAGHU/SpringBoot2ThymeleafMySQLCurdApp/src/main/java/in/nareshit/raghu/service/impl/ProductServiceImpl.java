package in.nareshit.raghu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;
import in.nareshit.raghu.service.IProductService;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	private ProductRepository repo;

	@Override
	public Integer saveProduct(Product p) {
		// local variable type inference
		// data type is provided by java compiler
		var cost = p.getCost();
		var discount = cost * 10/100.0;
		var gst = cost * 8/100.0;
		p.setDiscount(discount);
		p.setGst(gst);
		return repo.save(p).getId();
	}

	@Override
	public void updateProduct(Product p) {
		var cost = p.getCost();
		var discount = cost * 10/100.0;
		var gst = cost * 8/100.0;
		p.setDiscount(discount);
		p.setGst(gst);
		repo.save(p);
	}

	@Override
	public void deleteProduct(Integer id) {
		Product p = getOneProduct(id);
		repo.delete(p);
		//repo.deleteById(id);
	}

	@Override
	public Product getOneProduct(Integer id) {
		/*
		Optional<Product> opt = repo.findById(id);
		if(opt.isPresent())
			return opt.get();
		else
			throw new ProductNotFoundException("Product '"+id+"' Not exist");
		 */
		Product p = repo.findById(id)
				.orElseThrow(
						()->
						new ProductNotFoundException("Product '"+id+"' Not exist")
						);
		return p;
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public boolean existProduct(Integer id) {
		return repo.existsById(id);
	}

}
