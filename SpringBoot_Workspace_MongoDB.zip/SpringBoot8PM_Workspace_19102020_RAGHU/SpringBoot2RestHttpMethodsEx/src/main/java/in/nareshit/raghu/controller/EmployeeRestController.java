package in.nareshit.raghu.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class EmployeeRestController {

	@GetMapping("/all")
	public ResponseEntity<String> getEmployees(){
		return new ResponseEntity<String>("FETCHING DATA",HttpStatus.OK);
	}
	
	@PostMapping("/save")
	public ResponseEntity<String> saveEmployee(){
		return new ResponseEntity<String>("SAVING DATA",HttpStatus.OK);
	}
	
	@PutMapping("/modify")
	public ResponseEntity<String> updateEmployee(){
		return new ResponseEntity<String>("MODIFYING DATA",HttpStatus.OK);
	}
	
	@DeleteMapping("/remove")
	public ResponseEntity<String> deleteEmployee(){
		return new ResponseEntity<String>("DELETING DATA",HttpStatus.OK);
	}
	
	
}
