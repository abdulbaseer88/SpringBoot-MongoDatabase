package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Product;

@Component
public class ProductUtil {

	public Product calculateGst(Product p) {
		var cost = p.getProdCost();
		p.setProdGst(cost * 12/100.0);
		return p;
	}
	
	public void copyNonNullValues(Product req,Product db) {
		if(req.getProdCode()!=null) {
			db.setProdCode(req.getProdCode());
		}
		if(req.getProdCost()!=null ) {
			db.setProdCost(req.getProdCost());
		}
		if(req.getVendorName()!=null) {
			db.setVendorName(req.getVendorName());
		}
		
	}
}
