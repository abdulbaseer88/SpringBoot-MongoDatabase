package in.nareshit.raghu.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.nareshit.raghu.exception.ProductNotFoundException;
import in.nareshit.raghu.model.Product;
import in.nareshit.raghu.repo.ProductRepository;
import in.nareshit.raghu.service.IProductService;
import in.nareshit.raghu.util.ProductUtil;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	private ProductRepository repo;
	
	@Autowired
	private ProductUtil util;

	@Override
	public Integer saveProduct(Product p) {
		util.calculateGst(p);
		return repo.save(p).getId();
	}

	@Override
	public void updateProduct(Product p) {
		util.calculateGst(p);
		repo.save(p);
	}

	@Override
	public void deleteProduct(Integer id) {
		Product p = getOneProduct(id);
		repo.delete(p);
	}

	@Override
	public Product getOneProduct(Integer id) {
		Product p = repo.findById(id)
		.orElseThrow(()-> new ProductNotFoundException(
				new StringBuffer()
				.append("Product '")
				.append(id)
				.append("' not exist")
				.toString())
				);
		return p;
	}

	@Override
	public List<Product> getAllProduct() {
		List<Product> list = repo.findAll();
		list.sort(
				(p1,p2) -> 
				p1.getId().compareTo(p2.getId())
				);
		return list;
	}

	@Override
	@Transactional
	public Integer updateProductCodeById(
			String code, Integer id) 
	{
		
		if(!repo.existsById(id)) { //if not exist
			throw new ProductNotFoundException(
					new StringBuffer()
					.append("Product '")
					.append(id)
					.append("' not exist")
					.toString());
		}
		
		return repo.updateProductCodeById(code, id);
	}
	
}
