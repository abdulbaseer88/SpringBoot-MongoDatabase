package in.nareshit.raghu.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Document // Maps Model class objects as JSON Documents
public class Employee {
	@Id // makes this variable as ID and auto-generated
	private String id;
	
	@NonNull
	private Integer eid;
	@NonNull
	private String ename;
	@NonNull
	private Double esal;
}
