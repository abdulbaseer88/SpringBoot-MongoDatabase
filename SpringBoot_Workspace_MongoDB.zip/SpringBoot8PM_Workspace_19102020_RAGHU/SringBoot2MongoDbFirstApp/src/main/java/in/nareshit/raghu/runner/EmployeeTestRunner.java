package in.nareshit.raghu.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Employee;
import in.nareshit.raghu.repo.EmployeeRepository;

@Component
public class EmployeeTestRunner implements CommandLineRunner {
	@Autowired
	private EmployeeRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		
		System.out.println(repo.getClass().getName());
		
		repo.deleteAll();
		
		repo.save(new Employee(101,"A",5000.0));
		repo.save(new Employee(102,"B",6000.0));
		repo.save(new Employee(103,"C",7000.0));
		repo.save(new Employee(104,"D",8000.0));
		
		System.out.println("___DONE____");
	}

}
