package in.nareshit.raghu.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import in.nareshit.raghu.model.Student;

public interface StudentRepository 
	extends MongoRepository<Student, String> {

	
}
