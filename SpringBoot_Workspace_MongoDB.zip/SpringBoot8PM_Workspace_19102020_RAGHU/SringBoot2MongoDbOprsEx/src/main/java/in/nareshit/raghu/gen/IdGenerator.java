package in.nareshit.raghu.gen;

import java.util.UUID;

public class IdGenerator {

	public static String getId() {
		//JDK 1.5
		return UUID.randomUUID().toString()
		.replaceAll("-", "")
		.substring(0, 8);
	}
	
	
}
