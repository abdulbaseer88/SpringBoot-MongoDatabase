package in.nareshit.raghu.model;

import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Student {
	@Id
	private String id;
	
	private Integer stdId;
	private String stdName;
	
	private List<Integer> stdMarks;
	private String[] stdSubjNames;
	//private Set<String> stdSubjNames;
	
	private Map<String,String> examGrades;
	
	
}
