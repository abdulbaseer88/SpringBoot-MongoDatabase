package in.nareshit.raghu.runner;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.StudentRepository;

@Component
public class StudentTestOneRunner implements CommandLineRunner {
	@Autowired
	private StudentRepository repo;

	@Override
	public void run(String... args) throws Exception {
		repo.deleteAll(); // like ddl-auto-create


		repo.save(new Student("A001",101, "A",
					List.of(83,95,76),
					new String[] {"ENG","MAT","SCI"},
					//Set.of("ENG","MAT","SCI")
					Map.of("ENG","A","MAT","A+","SCI","B")
					));


		System.out.println("___Done___");

	}

}
