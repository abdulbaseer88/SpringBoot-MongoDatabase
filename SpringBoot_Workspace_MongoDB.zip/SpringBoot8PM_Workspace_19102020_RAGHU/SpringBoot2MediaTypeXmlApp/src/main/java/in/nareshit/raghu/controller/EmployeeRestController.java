package in.nareshit.raghu.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.nareshit.raghu.model.Employee;

@RestController
public class EmployeeRestController {

	@PostMapping("/save")
	public Employee saveEmp(
			@RequestBody Employee employee)
	{
		return employee;
	}
}
